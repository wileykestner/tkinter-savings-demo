from setuptools import setup

setup(name="savings",
      version="0.0.1",
      test_suite="savings_tests",
      packages=["savings"])
